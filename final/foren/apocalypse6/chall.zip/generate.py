#!/usr/bin/env python3
from PIL import Image
from random import randint
import io

flag = open('flag.txt', 'rb').read().strip()
# hapus format flag
flag = flag[10:-1]

output = b''
before = b''

for i, byte in enumerate(flag):
    image = Image.new('RGBA', (1600, 1600), color=(255, 255, 255, 255))

    # adding flag as black and white pixels
    for j in range(8):
        color = 255 * (byte % 2)
        image.putpixel((j, 1599), (color, color, color, 255))
        byte = byte >> 1

    # adding more IDAT chunks
    for x in range(image.width):
        height = 1100 - (1100//len(flag))*i
        for y in range(height):
            image.putpixel((x, y), (randint(0, 255), randint(0, 255), randint(0, 255), randint(0, 255)))

    temp = io.BytesIO()
    image.save(temp, format='PNG')

    if i > 0:
        assert len(temp.getvalue()) < len(before)
        
    before = temp.getvalue()
    output = before + output[len(before):]

with open('output.png', 'wb') as f:
    f.write(output)
